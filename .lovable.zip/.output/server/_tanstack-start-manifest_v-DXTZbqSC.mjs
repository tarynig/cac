//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DXTZbqSC.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Business/CAC/lovable/dual-course-buddy/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/auth",
			"/contact",
			"/courses",
			"/dual-courses",
			"/health"
		],
		preloads: [
			"/assets/index-Cw9HcOqx.js",
			"/assets/useRouter-BOAPZDg1.js",
			"/assets/not-found-DIgawKw1.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cw9HcOqx.js"
		} }]
	},
	"/": {
		filePath: "C:/Business/CAC/lovable/dual-course-buddy/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C3A64Dxt.js",
			"/assets/route-fallbacks-D2Ye7Ujq.js",
			"/assets/routes-CR_UEP7I.js",
			"/assets/useSuspenseQuery-BEUhKRT1.js",
			"/assets/course-cards-_57Pi5hd.js",
			"/assets/routes-CSSMj6cL.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/Business/CAC/lovable/dual-course-buddy/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/admin"],
		preloads: ["/assets/route-Cephu5GO.js"]
	},
	"/about": {
		filePath: "C:/Business/CAC/lovable/dual-course-buddy/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-teLiXNsr.js"]
	},
	"/auth": {
		filePath: "C:/Business/CAC/lovable/dual-course-buddy/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-PJOatKOy.js", "/assets/useServerFn-Ce9Hqk15.js"]
	},
	"/contact": {
		filePath: "C:/Business/CAC/lovable/dual-course-buddy/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-C3A64Dxt.js",
			"/assets/route-fallbacks-D2Ye7Ujq.js",
			"/assets/contact-CHeZTFUq.js",
			"/assets/useServerFn-Ce9Hqk15.js",
			"/assets/useSuspenseQuery-BEUhKRT1.js",
			"/assets/contact-CSSMj6cL.js"
		]
	},
	"/courses": {
		filePath: "C:/Business/CAC/lovable/dual-course-buddy/src/routes/courses.tsx",
		children: void 0,
		preloads: [
			"/assets/courses-C3A64Dxt.js",
			"/assets/route-fallbacks-D2Ye7Ujq.js",
			"/assets/courses-CSSMj6cL.js",
			"/assets/courses-CTgq0YVq.js",
			"/assets/useSuspenseQuery-BEUhKRT1.js",
			"/assets/course-cards-_57Pi5hd.js"
		]
	},
	"/dual-courses": {
		filePath: "C:/Business/CAC/lovable/dual-course-buddy/src/routes/dual-courses.tsx",
		children: void 0,
		preloads: [
			"/assets/dual-courses-C3A64Dxt.js",
			"/assets/route-fallbacks-D2Ye7Ujq.js",
			"/assets/dual-courses-CSSMj6cL.js",
			"/assets/dual-courses-DVEFCGL1.js",
			"/assets/useSuspenseQuery-BEUhKRT1.js",
			"/assets/course-cards-_57Pi5hd.js"
		]
	},
	"/_authenticated/admin": {
		filePath: "C:/Business/CAC/lovable/dual-course-buddy/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BlHK-n1D.js",
			"/assets/route-fallbacks-D2Ye7Ujq.js",
			"/assets/admin-ByvKt7Nc.js",
			"/assets/admin-DTOEHvj9.js",
			"/assets/useServerFn-Ce9Hqk15.js",
			"/assets/useBaseQuery-DPWLoGZ-.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
