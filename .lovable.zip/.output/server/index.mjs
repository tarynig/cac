globalThis.__nitro_main__ = import.meta.url;
import { o as NodeResponse, s as serve } from "./_libs/h3-v2+rou3+srvx.mjs";
import { i as toEventHandler, n as defineHandler, o as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/about-teLiXNsr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14cd-RLfAZDOd8I7rB3iviOTQPc4pkVc\"",
		"mtime": "2026-10-01T19:22:37.896Z",
		"size": 5325,
		"path": "../public/assets/about-teLiXNsr.js"
	},
	"/assets/admin-BlHK-n1D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"59-vZEehaU/+SQo6SmMdyAVxgfkVtI\"",
		"mtime": "2026-10-01T19:22:37.896Z",
		"size": 89,
		"path": "../public/assets/admin-BlHK-n1D.js"
	},
	"/assets/admin-ByvKt7Nc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"56-hpLYRB1o8zrKaNivyxIyGQpJdnk\"",
		"mtime": "2026-10-01T19:22:37.897Z",
		"size": 86,
		"path": "../public/assets/admin-ByvKt7Nc.js"
	},
	"/assets/admin-DTOEHvj9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2848-vwLiPLm83o3akYBF52/BRVmFJkU\"",
		"mtime": "2026-10-01T19:22:37.897Z",
		"size": 10312,
		"path": "../public/assets/admin-DTOEHvj9.js"
	},
	"/assets/contact-C3A64Dxt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-7aSnXRE/ZtNGn3kO11w5lBh5vOY\"",
		"mtime": "2026-10-01T19:22:37.898Z",
		"size": 165,
		"path": "../public/assets/contact-C3A64Dxt.js"
	},
	"/assets/auth-PJOatKOy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"94d-cOkWd9KXHl9K1KBkFbsAtBt24u0\"",
		"mtime": "2026-10-01T19:22:37.898Z",
		"size": 2381,
		"path": "../public/assets/auth-PJOatKOy.js"
	},
	"/assets/contact-CHeZTFUq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"173c-4QZRz75E3YfbNdqC6pysTKqDKw0\"",
		"mtime": "2026-10-01T19:22:37.899Z",
		"size": 5948,
		"path": "../public/assets/contact-CHeZTFUq.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-10-01T12:18:57.376Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-01T12:18:57.383Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/contact-CSSMj6cL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d-OYjR/Zkz6dHvD6aPbZEqeA9Eqak\"",
		"mtime": "2026-10-01T19:22:37.899Z",
		"size": 157,
		"path": "../public/assets/contact-CSSMj6cL.js"
	},
	"/assets/course-cards-_57Pi5hd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e43-kvvG59cQdIG/tnmc3mD0KpQ/7GI\"",
		"mtime": "2026-10-01T19:22:37.900Z",
		"size": 3651,
		"path": "../public/assets/course-cards-_57Pi5hd.js"
	},
	"/assets/courses-C3A64Dxt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-7aSnXRE/ZtNGn3kO11w5lBh5vOY\"",
		"mtime": "2026-10-01T19:22:37.900Z",
		"size": 165,
		"path": "../public/assets/courses-C3A64Dxt.js"
	},
	"/assets/courses-CSSMj6cL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d-OYjR/Zkz6dHvD6aPbZEqeA9Eqak\"",
		"mtime": "2026-10-01T19:22:37.901Z",
		"size": 157,
		"path": "../public/assets/courses-CSSMj6cL.js"
	},
	"/assets/dual-courses-C3A64Dxt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-7aSnXRE/ZtNGn3kO11w5lBh5vOY\"",
		"mtime": "2026-10-01T19:22:37.901Z",
		"size": 165,
		"path": "../public/assets/dual-courses-C3A64Dxt.js"
	},
	"/assets/courses-CTgq0YVq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b46-P5gZaroFzDq4rtpqCpgYs0qVRJM\"",
		"mtime": "2026-10-01T19:22:37.901Z",
		"size": 2886,
		"path": "../public/assets/courses-CTgq0YVq.js"
	},
	"/assets/dual-courses-DVEFCGL1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5f-lqw8rj7V50PsgNYxpOFjEvtJQNU\"",
		"mtime": "2026-10-01T19:22:37.902Z",
		"size": 3423,
		"path": "../public/assets/dual-courses-DVEFCGL1.js"
	},
	"/assets/dual-courses-CSSMj6cL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d-OYjR/Zkz6dHvD6aPbZEqeA9Eqak\"",
		"mtime": "2026-10-01T19:22:37.902Z",
		"size": 157,
		"path": "../public/assets/dual-courses-CSSMj6cL.js"
	},
	"/assets/route-Cephu5GO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8b-pSipTA7FNsMtJC6iFaDSgdpbv/g\"",
		"mtime": "2026-10-01T19:22:37.907Z",
		"size": 139,
		"path": "../public/assets/route-Cephu5GO.js"
	},
	"/assets/not-found-DIgawKw1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37-RTB6YH5iXRKeXz1Sn6ZQ+vS0lnc\"",
		"mtime": "2026-10-01T19:22:37.902Z",
		"size": 55,
		"path": "../public/assets/not-found-DIgawKw1.js"
	},
	"/assets/route-fallbacks-D2Ye7Ujq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"58d-8QoISi7oWXCLPS/1LZdhJm0Xu2A\"",
		"mtime": "2026-10-01T19:22:37.908Z",
		"size": 1421,
		"path": "../public/assets/route-fallbacks-D2Ye7Ujq.js"
	},
	"/assets/routes-C3A64Dxt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-7aSnXRE/ZtNGn3kO11w5lBh5vOY\"",
		"mtime": "2026-10-01T19:22:37.909Z",
		"size": 165,
		"path": "../public/assets/routes-C3A64Dxt.js"
	},
	"/assets/routes-CR_UEP7I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"135c-TJJqJIMhCvIW+LlDEZ7Nz/dvFkQ\"",
		"mtime": "2026-10-01T19:22:37.909Z",
		"size": 4956,
		"path": "../public/assets/routes-CR_UEP7I.js"
	},
	"/assets/routes-CSSMj6cL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d-OYjR/Zkz6dHvD6aPbZEqeA9Eqak\"",
		"mtime": "2026-10-01T19:22:37.910Z",
		"size": 157,
		"path": "../public/assets/routes-CSSMj6cL.js"
	},
	"/assets/styles-DHBIoCdU.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"12e4d-Lqx1N0vjhsflSxfidIkv+UEFyys\"",
		"mtime": "2026-10-01T19:22:37.913Z",
		"size": 77389,
		"path": "../public/assets/styles-DHBIoCdU.css"
	},
	"/assets/index-Cw9HcOqx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c220-Fonw7vIWVM0hof3bxCrutGbQTbs\"",
		"mtime": "2026-10-01T19:22:37.896Z",
		"size": 377376,
		"path": "../public/assets/index-Cw9HcOqx.js"
	},
	"/assets/useRouter-BOAPZDg1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"229c-q+MRbm7Q8Y/gJEgHL0SVvRyYkQo\"",
		"mtime": "2026-10-01T19:22:37.911Z",
		"size": 8860,
		"path": "../public/assets/useRouter-BOAPZDg1.js"
	},
	"/assets/useBaseQuery-DPWLoGZ-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f24-mcMsOkD79ItGzKmEZZv2wZbQyGc\"",
		"mtime": "2026-10-01T19:22:37.911Z",
		"size": 7972,
		"path": "../public/assets/useBaseQuery-DPWLoGZ-.js"
	},
	"/assets/useServerFn-Ce9Hqk15.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16e-0/DnHw0CM9PVNmlia0zqZtWaUfI\"",
		"mtime": "2026-10-01T19:22:37.912Z",
		"size": 366,
		"path": "../public/assets/useServerFn-Ce9Hqk15.js"
	},
	"/assets/useSuspenseQuery-BEUhKRT1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-2SjJeaOODUvOT6a1uYY7yphQX0w\"",
		"mtime": "2026-10-01T19:22:37.912Z",
		"size": 174,
		"path": "../public/assets/useSuspenseQuery-BEUhKRT1.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_nz11u7 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_nz11u7
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
