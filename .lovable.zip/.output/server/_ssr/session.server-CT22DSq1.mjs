import { db } from "./db.server-BN4FZ3Ea.mjs";
import { a as setCookie$1, n as getCookie, t as deleteCookie$1 } from "./request-response-CGAbTyAP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session.server-CT22DSq1.js
var SESSION_COOKIE = "cac_session";
async function sha256(value) {
	const { createHash } = await import("node:crypto");
	return createHash("sha256").update(value, "utf8").digest("hex");
}
async function newToken() {
	const { randomBytes } = await import("node:crypto");
	return randomBytes(32).toString("hex");
}
async function createSession(userId) {
	const token = await newToken();
	const tokenHash = await sha256(token);
	const expiresAt = new Date(Date.now() + 12096e5);
	await db()`
    INSERT INTO public.app_sessions (user_id, token_hash, expires_at)
    VALUES (${userId}, ${tokenHash}, ${expiresAt})
  `;
	setCookie$1(SESSION_COOKIE, token, {
		httpOnly: true,
		secure: true,
		sameSite: "none",
		partitioned: true,
		path: "/",
		maxAge: 1209600
	});
}
async function readSession() {
	const token = getCookie(SESSION_COOKIE);
	if (!token) return null;
	const tokenHash = await sha256(token);
	return (await db()`
    SELECT u.id, u.email, u.role
    FROM public.app_sessions s
    JOIN public.app_users u ON u.id = s.user_id
    WHERE s.token_hash = ${tokenHash}
      AND s.expires_at > now()
      AND u.is_active
    LIMIT 1
  `)[0] ?? null;
}
async function destroySession() {
	const token = getCookie(SESSION_COOKIE);
	if (token) {
		const tokenHash = await sha256(token);
		await db()`DELETE FROM public.app_sessions WHERE token_hash = ${tokenHash}`;
	}
	deleteCookie$1(SESSION_COOKIE, {
		path: "/",
		secure: true,
		sameSite: "none",
		partitioned: true
	});
}
async function requireUser() {
	const user = await readSession();
	if (!user) throw new Error("Unauthorized");
	return user;
}
async function requireAdmin() {
	const user = await requireUser();
	if (user.role !== "admin") throw new Error("Forbidden");
	return user;
}
//#endregion
export { createSession, destroySession, readSession, requireAdmin, requireUser };
