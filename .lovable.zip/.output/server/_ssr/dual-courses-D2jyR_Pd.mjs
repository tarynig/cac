import { o as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as CatalogueError } from "./route-fallbacks-DzNM5BHJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dual-courses-D2jyR_Pd.js
var import_jsx_runtime = require_jsx_runtime();
var SplitErrorComponent = ({ error }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogueError, { error });
//#endregion
export { SplitErrorComponent as errorComponent };
