import { i as __toESM } from "../_runtime.mjs";
import { n as useSuspenseQuery, o as require_jsx_runtime, s as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { t as contact } from "./courses-Q7G0sZVb.mjs";
import { n as submitEnquiry, t as catalogueQueryOptions } from "./catalogue-queries-BI5JU7nB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-BCXioICA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	const { data: catalogue } = useSuspenseQuery(catalogueQueryOptions);
	const submitFn = useServerFn(submitEnquiry);
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [errorMessage, setErrorMessage] = (0, import_react.useState)("");
	const onSubmit = async (e) => {
		e.preventDefault();
		const form = e.currentTarget;
		const data = new FormData(form);
		const interest = String(data.get("interest") ?? "");
		const [kind, id] = interest.includes(":") ? interest.split(":") : ["", ""];
		setStatus("sending");
		const result = await submitFn({ data: {
			fullName: String(data.get("name") ?? ""),
			phone: String(data.get("phone") ?? ""),
			email: String(data.get("email") ?? ""),
			courseId: kind === "course" ? id : null,
			dualCourseId: kind === "dual" ? id : null,
			campus: String(data.get("campus") ?? ""),
			message: String(data.get("message") ?? "") || null
		} });
		if (result.ok) {
			setStatus("sent");
			form.reset();
		} else {
			setStatus("error");
			setErrorMessage(result.error);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "surface-deep dot-grid",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold tracking-[0.3em] text-secondary uppercase",
					children: "Limited seats"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-4xl font-black md:text-5xl",
					children: "Apply for 2027"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-sm opacity-85 md:text-base",
					children: "Tell us which course or dual course you're after and an advisor will come back to you with the fee sheet, intake dates and registration deposit."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid max-w-6xl gap-6 px-5 py-14 lg:grid-cols-[1.1fr_0.9fr]",
		children: [status === "sent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-start justify-center rounded-2xl border-2 border-secondary bg-card p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-black text-primary",
					children: "Enquiry received"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: [
						"Thank you — an advisor will contact you with the fee sheet, intake dates and registration deposit. If you'd like to speak to someone sooner, call us on",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `tel:${contact.phone.replace(/\s/g, "")}`,
							className: "font-bold text-secondary",
							children: contact.phone
						}),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setStatus("idle"),
					className: "mt-6 rounded-full border border-border px-5 py-2.5 text-sm font-bold text-muted-foreground hover:bg-muted",
					children: "Send another enquiry"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "rounded-2xl border border-border bg-card p-6",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-black",
					children: "Enquiry"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Full name",
							name: "name",
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Mobile number",
							name: "phone",
							type: "tel",
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email address",
							name: "email",
							type: "email",
							required: true,
							className: "sm:col-span-2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "interest",
								className: "text-sm font-bold",
								children: "Course of interest"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "interest",
								name: "interest",
								className: "mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Not sure yet"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
										label: "Dual courses",
										children: catalogue.duals.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: `dual:${d.id}`,
											children: [d.title, " (dual)"]
										}, d.id))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
										label: "Individual courses",
										children: catalogue.courses.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: `course:${c.id}`,
											children: c.name
										}, c.id))
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "campus",
								className: "text-sm font-bold",
								children: "Preferred campus"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "campus",
								name: "campus",
								className: "mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm",
								children: [contact.campuses.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c.city }, c.city)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Blended / online" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "message",
								className: "text-sm font-bold",
								children: "Message (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								id: "message",
								name: "message",
								rows: 4,
								className: "mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm"
							})]
						})
					]
				}),
				status === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-xl bg-gold/20 px-4 py-3 text-sm font-semibold text-gold-foreground",
					children: errorMessage
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: status === "sending",
					className: "mt-6 w-full rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60",
					children: status === "sending" ? "Sending…" : "Send enquiry"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted-foreground",
					children: "Registration deposits will be payable online once payments go live."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-primary p-6 text-primary-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-[0.3em] uppercase opacity-70",
						children: "Call us"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `tel:${contact.phone.replace(/\s/g, "")}`,
						className: "mt-2 block font-display text-3xl font-black",
						children: contact.phone
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm opacity-80",
						children: contact.website
					})
				]
			}), contact.campuses.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-lg font-black",
						children: c.city
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: c.address
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `tel:${c.phone.replace(/\s/g, "")}`,
						className: "mt-2 inline-block text-sm font-bold text-secondary",
						children: c.phone
					})
				]
			}, c.city))]
		})]
	})] });
}
function Field({ label, name, type = "text", required, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: name,
			className: "text-sm font-bold",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: name,
			name,
			type,
			required,
			className: "mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm"
		})]
	});
}
//#endregion
export { ContactPage as component };
