import { i as __toESM } from "../_runtime.mjs";
import { i as QueryClientProvider, o as require_jsx_runtime, s as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { K as redirect, _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as contact } from "./courses-Q7G0sZVb.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as catalogueQueryOptions } from "./catalogue-queries-BI5JU7nB.mjs";
import { n as getCurrentUser } from "./auth.functions-D8WfPioE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BVeD60yz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DHBIoCdU.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var nav = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/courses",
		label: "Courses"
	},
	{
		to: "/dual-courses",
		label: "Dual Courses"
	},
	{
		to: "/about",
		label: "About"
	},
	{
		to: "/contact",
		label: "Apply"
	}
];
function Logo({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: "inline-flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-9 place-items-center rounded-full border-2 border-secondary text-lg font-black text-secondary",
			children: "C"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "block font-display text-lg font-black tracking-tight",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-secondary",
					children: "creative"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-primary",
					children: "arts"
				})]
			}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-[0.6rem] font-semibold tracking-[0.42em] text-muted-foreground",
				children: "COLLEGE"
			})]
		})]
	});
}
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-50 border-b border-border bg-card/90 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-1 md:flex",
					children: [nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						activeOptions: { exact: item.to === "/" },
						activeProps: { className: "bg-accent text-accent-foreground" },
						className: "rounded-full px-4 py-2 text-sm font-semibold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
						children: item.label
					}, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `tel:${contact.phone.replace(/\s/g, "")}`,
						className: "ml-2 rounded-full bg-primary px-4 py-2 text-sm font-bold text-primary-foreground transition-opacity hover:opacity-90",
						children: contact.phone
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setOpen((v) => !v),
					"aria-label": "Toggle menu",
					"aria-expanded": open,
					className: "rounded-lg border border-border px-3 py-2 text-sm font-semibold md:hidden",
					children: "Menu"
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "grid gap-1 border-t border-border bg-card px-5 py-3 md:hidden",
			children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: item.to,
				onClick: () => setOpen(false),
				className: "rounded-lg px-3 py-2 text-sm font-semibold text-foreground hover:bg-muted",
				children: item.label
			}, item.to))
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "surface-deep mt-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-black",
						children: "Creative Arts College"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xs text-sm opacity-80",
						children: "A division of the South African Film Institute Group. Real industry — relevant education."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm font-semibold text-secondary",
						children: contact.website
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm font-bold tracking-[0.2em] uppercase opacity-70",
					children: "Campuses"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-4 text-sm",
					children: contact.campuses.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold",
							children: c.city
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "opacity-80",
							children: c.address
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `tel:${c.phone.replace(/\s/g, "")}`,
							className: "opacity-80 underline",
							children: c.phone
						})
					] }, c.city))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-bold tracking-[0.2em] uppercase opacity-70",
						children: "Explore"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2 text-sm",
						children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: "opacity-80 hover:opacity-100",
							children: item.label
						}) }, item.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-xs opacity-60",
						children: "Accredited by QCTO, MICT-SETA, CATHSSETA and ICITP. PR20250064GP"
					})
				] })
			]
		})
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$9 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Creative Arts College | Where Education & Industry Meet" },
			{
				name: "description",
				content: "Accredited, practical, industry-based courses and great-value dual courses from Creative Arts College, South Africa."
			},
			{
				name: "author",
				content: "Creative Arts College"
			},
			{
				property: "og:title",
				content: "Creative Arts College"
			},
			{
				property: "og:description",
				content: "Where education & industry meet. 30+ accredited SAQA qualifications."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Outfit:wght@500;700;800;900&family=DM+Sans:wght@400;500;700&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$9.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-screen flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
			]
		})
	});
}
var $$splitComponentImporter$7 = () => import("./routes-S2e-S9y8.mjs");
var $$splitNotFoundComponentImporter$4 = () => import("./routes-BtiMjh_o.mjs");
var $$splitErrorComponentImporter$4 = () => import("./routes-N7Q6R09Q.mjs");
var Route$8 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Creative Arts College | Where Education & Industry Meet" },
		{
			name: "description",
			content: "30+ accredited SAQA qualifications in film, audio, design, fashion, IT and business. Practical, industry-based study in 12–24 months, plus great-value dual courses."
		},
		{
			property: "og:title",
			content: "Creative Arts College | 2027 Prospectus"
		},
		{
			property: "og:description",
			content: "Accredited, practical, industry-owned education in South Africa. Explore courses and money-saving dual programmes for 2027."
		}
	] }),
	loader: ({ context }) => context.queryClient.ensureQueryData(catalogueQueryOptions),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter$4, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$4, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./route-Di7iQBCH.mjs");
var Route$7 = createFileRoute("/_authenticated")({
	beforeLoad: async () => {
		const user = await getCurrentUser();
		if (!user) throw redirect({ to: "/auth" });
		return { user };
	},
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./about-ffpbWHH_.mjs");
var Route$6 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: "About & Accreditation | Creative Arts College" },
		{
			name: "description",
			content: "An award-winning DHET Institute of Excellence accredited under QCTO, MICT-SETA, CATHSSETA and ICITP, owned by the South African Film Institute Group."
		},
		{
			property: "og:title",
			content: "About & Accreditation | Creative Arts College"
		},
		{
			property: "og:description",
			content: "Where education and industry meet — accredited, practical, industry-owned education in South Africa."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./auth-Bbmy9P7U.mjs");
var Route$5 = createFileRoute("/auth")({
	head: () => ({ meta: [
		{ title: "Staff sign in | Creative Arts College" },
		{
			name: "description",
			content: "Sign in to the Creative Arts College staff area to manage course fees and student enquiries."
		},
		{
			property: "og:title",
			content: "Staff sign in | Creative Arts College"
		},
		{
			property: "og:description",
			content: "Staff access to the Creative Arts College enquiry inbox and fee manager."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./contact-BCXioICA.mjs");
var $$splitNotFoundComponentImporter$3 = () => import("./contact-DsLr6VNH.mjs");
var $$splitErrorComponentImporter$3 = () => import("./contact-rBCN721C.mjs");
var Route$4 = createFileRoute("/contact")({
	head: () => ({ meta: [
		{ title: "Apply & Enquire — Limited Seats | Creative Arts College" },
		{
			name: "description",
			content: "Reserve your 2027 seat at Creative Arts College. Durban and Pietermaritzburg campuses — call us or send an enquiry for the full fee sheet."
		},
		{
			property: "og:title",
			content: "Apply & Enquire | Creative Arts College"
		},
		{
			property: "og:description",
			content: "Limited seats for 2027. Speak to an advisor about courses, dual courses and fees."
		}
	] }),
	loader: ({ context }) => context.queryClient.ensureQueryData(catalogueQueryOptions),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter$3, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$3, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./courses-BDK7CvZ1.mjs");
var $$splitNotFoundComponentImporter$2 = () => import("./courses-Dy8vJTmM.mjs");
var $$splitErrorComponentImporter$2 = () => import("./courses-2NVWuCbJ.mjs");
var Route$3 = createFileRoute("/courses")({
	head: () => ({ meta: [
		{ title: "Courses 2027 | Creative Arts College" },
		{
			name: "description",
			content: "Browse 30+ accredited SAQA qualifications and skills programmes across audio, film, performance, design, fashion, IT and business."
		},
		{
			property: "og:title",
			content: "Courses 2027 | Creative Arts College"
		},
		{
			property: "og:description",
			content: "Accredited, practical, industry-based courses from 12 to 24 months across seven faculties."
		}
	] }),
	loader: ({ context }) => context.queryClient.ensureQueryData(catalogueQueryOptions),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter$2, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$2, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./dual-courses-DoXLJVlo.mjs");
var $$splitNotFoundComponentImporter$1 = () => import("./dual-courses-J87VpQyv.mjs");
var $$splitErrorComponentImporter$1 = () => import("./dual-courses-D2jyR_Pd.mjs");
var Route$2 = createFileRoute("/dual-courses")({
	head: () => ({ meta: [
		{ title: "Dual Courses — Two Qualifications, One Timeline | Creative Arts College" },
		{
			name: "description",
			content: "Pair two complementary courses at a lower combined rate and finish far sooner than studying them one after the other. Find your pairing."
		},
		{
			property: "og:title",
			content: "Dual Courses | Creative Arts College"
		},
		{
			property: "og:description",
			content: "Strategically paired qualifications at better value and in less time. Use the dual-course finder."
		}
	] }),
	loader: ({ context }) => context.queryClient.ensureQueryData(catalogueQueryOptions),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter$1, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$1, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var Route$1 = createFileRoute("/health")({ server: { handlers: { GET: () => new Response("ok", { headers: { "content-type": "text/plain; charset=utf-8" } }) } } });
var $$splitComponentImporter = () => import("./admin-DvDvm0bB.mjs");
var $$splitNotFoundComponentImporter = () => import("./admin-8wpAoqiU.mjs");
var $$splitErrorComponentImporter = () => import("./admin-ywjVUOQb.mjs");
var Route = createFileRoute("/_authenticated/admin")({
	head: () => ({ meta: [
		{ title: "Staff dashboard | Creative Arts College" },
		{
			name: "description",
			content: "Manage student enquiries and course fees for Creative Arts College."
		},
		{
			property: "og:title",
			content: "Staff dashboard | Creative Arts College"
		},
		{
			property: "og:description",
			content: "Internal dashboard for enquiries and course fees."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$9
});
var AuthenticatedRouteRoute = Route$7.update({
	id: "/_authenticated",
	getParentRoute: () => Route$9
});
var AboutRoute = Route$6.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$9
});
var AuthRoute = Route$5.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$9
});
var ContactRoute = Route$4.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$9
});
var CoursesRoute = Route$3.update({
	id: "/courses",
	path: "/courses",
	getParentRoute: () => Route$9
});
var DualCoursesRoute = Route$2.update({
	id: "/dual-courses",
	path: "/dual-courses",
	getParentRoute: () => Route$9
});
var HealthRoute = Route$1.update({
	id: "/health",
	path: "/health",
	getParentRoute: () => Route$9
});
var AuthenticatedRouteRouteChildren = { AuthenticatedAdminRoute: Route.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AuthenticatedRouteRoute
}) };
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AboutRoute,
	AuthRoute,
	ContactRoute,
	CoursesRoute,
	DualCoursesRoute,
	HealthRoute
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
