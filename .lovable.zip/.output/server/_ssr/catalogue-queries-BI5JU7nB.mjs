import { t as queryOptions } from "../_libs/react+tanstack__react-query.mjs";
import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C9ESveN_.mjs";
import { i as stringType, r as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalogue-queries-BI5JU7nB.js
var getCatalogue = createServerFn({ method: "GET" }).handler(createSsrRpc("2a5f9abb9b53045eb26c71816c1a497d1c2f2b46176d16f7bde5d4ea8a3904c1"));
var enquirySchema = objectType({
	fullName: stringType().trim().min(2).max(120),
	phone: stringType().trim().min(5).max(40),
	email: stringType().trim().email().max(200),
	courseId: stringType().max(80).nullable().optional(),
	dualCourseId: stringType().max(80).nullable().optional(),
	campus: stringType().trim().min(1).max(80),
	message: stringType().trim().max(2e3).nullable().optional()
});
var submitEnquiry = createServerFn({ method: "POST" }).inputValidator((data) => enquirySchema.parse(data)).handler(createSsrRpc("f7608082995bee451bb3517974e4627a2cd7496f0631b1afb00f5845804a30ed"));
var catalogueQueryOptions = queryOptions({
	queryKey: ["catalogue"],
	queryFn: () => getCatalogue()
});
//#endregion
export { submitEnquiry as n, catalogueQueryOptions as t };
