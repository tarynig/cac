import { t as nodemailer } from "../_libs/nodemailer.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mail.server-D2Mx1xYT.js
var SITE_NAME = "Creative Arts College";
function settings() {
	const host = process.env["SMTP_HOST"];
	const user = process.env["SMTP_USER"];
	const pass = process.env["SMTP_PASS"];
	if (!host || !user || !pass) return null;
	const port = Number(process.env["SMTP_PORT"] ?? 465);
	const secureFlag = process.env["SMTP_SECURE"];
	return {
		host,
		port,
		secure: secureFlag ? secureFlag === "true" : port === 465,
		auth: {
			user,
			pass
		},
		from: process.env["SMTP_FROM"] ?? `"${SITE_NAME}" <${user}>`
	};
}
/** True once the mail account settings are present. */
function mailConfigured() {
	return settings() !== null;
}
/** Where enquiry notifications go (comma separated addresses). */
function teamRecipients() {
	return (process.env["ADMISSIONS_EMAIL"] ?? "").split(",").map((address) => address.trim().toLowerCase()).filter(Boolean);
}
async function sendMail(mail) {
	const config = settings();
	if (!config) {
		console.warn("[mail] SMTP is not configured — skipped:", mail.subject);
		return {
			sent: false,
			reason: "not_configured"
		};
	}
	const transport = nodemailer.createTransport({
		host: config.host,
		port: config.port,
		secure: config.secure,
		auth: config.auth,
		connectionTimeout: 8e3,
		greetingTimeout: 8e3,
		socketTimeout: 2e4
	});
	try {
		await transport.sendMail({
			from: config.from,
			...mail
		});
		return { sent: true };
	} catch (error) {
		console.error("[mail] send failed:", error);
		return {
			sent: false,
			reason: "send_failed"
		};
	} finally {
		transport.close();
	}
}
//#endregion
export { mailConfigured, sendMail, teamRecipients };
