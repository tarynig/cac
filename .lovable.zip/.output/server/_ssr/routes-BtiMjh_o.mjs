import { o as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as CatalogueNotFound } from "./route-fallbacks-DzNM5BHJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BtiMjh_o.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogueNotFound, {});
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
