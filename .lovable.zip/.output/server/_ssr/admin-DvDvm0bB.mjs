import { i as __toESM } from "../_runtime.mjs";
import { a as useQueryClient, o as require_jsx_runtime, r as useQuery, s as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { i as formatZar } from "./courses-Q7G0sZVb.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C9ESveN_.mjs";
import { i as stringType, n as numberType, r as objectType, t as enumType } from "../_libs/zod.mjs";
import { t as catalogueQueryOptions } from "./catalogue-queries-BI5JU7nB.mjs";
import { i as signOut, t as changePassword } from "./auth.functions-D8WfPioE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DvDvm0bB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var getAdminSession = createServerFn({ method: "GET" }).handler(createSsrRpc("e79aab6a9c5d4179f7a176a6a650c1161fe7e7439ce653697dcfba8240b8006e"));
var getAdminEnquiries = createServerFn({ method: "GET" }).handler(createSsrRpc("cbb9ec5068dc71699afb69ddeb7af1aba85e7ac03f0b71dda8f59fa196a9b26a"));
var setEnquiryStatus = createServerFn({ method: "POST" }).inputValidator((data) => objectType({
	id: stringType().uuid(),
	status: enumType([
		"new",
		"contacted",
		"enrolled",
		"closed"
	])
}).parse(data)).handler(createSsrRpc("1c425e3d55481dab9f73d0579f2f2099b3bfd62368d0a58b68d9036f158f3052"));
var setFees = createServerFn({ method: "POST" }).inputValidator((data) => objectType({
	kind: enumType(["course", "dual"]),
	id: stringType().min(1).max(80),
	fee: numberType().min(0).max(1e7).nullable(),
	deposit: numberType().min(0).max(1e7).nullable()
}).parse(data)).handler(createSsrRpc("a3daecf7ed272fa460dda5277a596af00aa4bf933ae45ddd9b54d1bb1bce087f"));
/** Sends the admissions notification template to the signed-in admin's own inbox. */
var sendTestEmail = createServerFn({ method: "POST" }).handler(createSsrRpc("cf361682af2d298d02de7c0ec6763b8ac233c3c2cada447d7edee0ac2ab23e41"));
var STATUSES = [
	"new",
	"contacted",
	"enrolled",
	"closed"
];
var TABS = [
	"enquiries",
	"fees",
	"account"
];
function AdminPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const [tab, setTab] = (0, import_react.useState)("enquiries");
	const fetchSession = useServerFn(getAdminSession);
	const endSession = useServerFn(signOut);
	const session = useQuery({
		queryKey: ["admin-session"],
		queryFn: () => fetchSession()
	});
	async function handleSignOut() {
		await queryClient.cancelQueries();
		queryClient.clear();
		await endSession({});
		navigate({
			to: "/auth",
			replace: true
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "surface-deep",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 py-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-xs font-bold tracking-[0.3em] text-secondary uppercase",
						children: "Creative Arts College"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-2xl font-black",
						children: "Staff dashboard"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4 text-sm",
						children: [session.data?.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "opacity-70",
							children: session.data.email
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: handleSignOut,
							className: "rounded-full border border-white/25 px-4 py-2 text-xs font-bold",
							children: "Sign out"
						})]
					})]
				})
			}),
			session.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto max-w-6xl px-5 py-16 text-sm text-muted-foreground",
				children: "Loading…"
			}),
			session.data && !session.data.isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-2xl px-5 py-24 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-black",
					children: "No access yet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "This account isn't an administrator. Ask an existing admin to grant you access."
				})]
			}),
			session.data?.isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(t),
						className: `rounded-full px-5 py-2 text-sm font-bold capitalize ${tab === t ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"}`,
						children: t
					}, t))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8",
					children: [
						tab === "enquiries" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnquiriesPanel, {}),
						tab === "fees" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeesPanel, {}),
						tab === "account" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailPanel, {})]
						})
					]
				})]
			})
		]
	});
}
function EnquiriesPanel() {
	const fetchEnquiries = useServerFn(getAdminEnquiries);
	const updateStatus = useServerFn(setEnquiryStatus);
	const enquiries = useQuery({
		queryKey: ["admin-enquiries"],
		queryFn: () => fetchEnquiries()
	});
	const catalogue = useQuery(catalogueQueryOptions);
	const queryClient = useQueryClient();
	const label = (courseId, dualId) => {
		const data = catalogue.data;
		if (courseId) return data?.courses.find((c) => c.id === courseId)?.name ?? courseId;
		if (dualId) return data?.duals.find((d) => d.id === dualId)?.title ?? dualId;
		return "Not sure yet";
	};
	if (enquiries.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Loading enquiries…"
	});
	if (enquiries.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-destructive",
		children: "Couldn't load enquiries. Please refresh."
	});
	if (!enquiries.data?.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "No enquiries yet."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: enquiries.data.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-2xl border border-border bg-card p-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-bold",
						children: e.fullName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${e.email}`,
								className: "underline",
								children: e.email
							}),
							" ",
							"·",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${e.phone.replace(/\s/g, "")}`,
								className: "underline",
								children: e.phone
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: label(e.courseId, e.dualCourseId)
							}),
							" ·",
							" ",
							e.campus,
							" campus"
						]
					}),
					e.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: e.message
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: new Date(e.createdAt).toLocaleString("en-ZA")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: e.status,
						onChange: async (event) => {
							await updateStatus({ data: {
								id: e.id,
								status: event.target.value
							} });
							queryClient.invalidateQueries({ queryKey: ["admin-enquiries"] });
						},
						className: "mt-2 rounded-full border border-border bg-background px-4 py-2 text-xs font-bold capitalize",
						children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})]
				})]
			})
		}, e.id))
	});
}
function FeesPanel() {
	const catalogue = useQuery(catalogueQueryOptions);
	const save = useServerFn(setFees);
	const queryClient = useQueryClient();
	const [saved, setSaved] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	async function handleSave(kind, id, fee, deposit) {
		setError(null);
		try {
			await save({ data: {
				kind,
				id,
				fee: fee.trim() === "" ? null : Number(fee),
				deposit: deposit.trim() === "" ? null : Number(deposit)
			} });
			setSaved(id);
			queryClient.invalidateQueries({ queryKey: ["catalogue"] });
			setTimeout(() => setSaved(null), 2e3);
		} catch {
			setError("Couldn't save that fee. Please try again.");
		}
	}
	if (catalogue.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Loading courses…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-black",
				children: "Dual course fees"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-3",
				children: catalogue.data?.duals.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeRow, {
					title: d.title,
					fee: d.fee,
					deposit: d.deposit,
					saved: saved === d.id,
					onSave: (fee, deposit) => handleSave("dual", d.id, fee, deposit)
				}, d.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-black",
				children: "Individual course fees"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-3",
				children: catalogue.data?.courses.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeRow, {
					title: c.name,
					fee: c.fee,
					deposit: c.deposit,
					saved: saved === c.id,
					onSave: (fee, deposit) => handleSave("course", c.id, fee, deposit)
				}, c.id))
			})] })
		]
	});
}
function FeeRow({ title, fee, deposit, saved, onSave }) {
	const [feeValue, setFeeValue] = (0, import_react.useState)(fee === null ? "" : String(fee));
	const [depositValue, setDepositValue] = (0, import_react.useState)(deposit === null ? "" : String(deposit));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-4 rounded-2xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-[14rem] flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["Currently ", fee === null ? "fees on request" : formatZar(fee)]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-xs font-bold tracking-widest uppercase text-muted-foreground",
				children: ["Total fee", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					min: 0,
					value: feeValue,
					onChange: (e) => setFeeValue(e.target.value),
					className: "mt-1 block w-32 rounded-lg border border-border bg-background px-3 py-2 text-sm font-normal"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-xs font-bold tracking-widest uppercase text-muted-foreground",
				children: ["Deposit", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					min: 0,
					value: depositValue,
					onChange: (e) => setDepositValue(e.target.value),
					className: "mt-1 block w-32 rounded-lg border border-border bg-background px-3 py-2 text-sm font-normal"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onSave(feeValue, depositValue),
				className: "rounded-full bg-primary px-5 py-2 text-xs font-bold text-primary-foreground",
				children: saved ? "Saved" : "Save"
			})
		]
	});
}
function AccountPanel() {
	const update = useServerFn(changePassword);
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	async function handleSubmit(event) {
		event.preventDefault();
		setMessage(null);
		setError(null);
		try {
			const result = await update({ data: {
				currentPassword,
				newPassword
			} });
			if (!result.ok) return setError(result.error);
			setCurrentPassword("");
			setNewPassword("");
			setMessage("Password updated.");
		} catch {
			setError("Couldn't update your password. Please try again.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-black",
				children: "Change your password"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Use at least 10 characters. You'll stay signed in on this device."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "mt-6 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-xs font-bold tracking-widest uppercase text-muted-foreground",
						children: ["Current password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "password",
							required: true,
							autoComplete: "current-password",
							value: currentPassword,
							onChange: (e) => setCurrentPassword(e.target.value),
							className: "mt-2 block w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-normal"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-xs font-bold tracking-widest uppercase text-muted-foreground",
						children: ["New password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "password",
							required: true,
							minLength: 10,
							autoComplete: "new-password",
							value: newPassword,
							onChange: (e) => setNewPassword(e.target.value),
							className: "mt-2 block w-full rounded-lg border border-border bg-background px-3 py-2 text-sm font-normal"
						})]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-destructive",
						children: error
					}),
					message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-primary",
						children: message
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "rounded-full bg-primary px-6 py-2 text-sm font-bold text-primary-foreground",
						children: "Update password"
					})
				]
			})
		]
	});
}
function EmailPanel() {
	const sendSample = useServerFn(sendTestEmail);
	const [state, setState] = (0, import_react.useState)("idle");
	const [error, setError] = (0, import_react.useState)("");
	async function handleSend() {
		setState("sending");
		setError("");
		try {
			const result = await sendSample({});
			if (result.ok) {
				setState("sent");
				return;
			}
			setError(result.error);
			setState("error");
		} catch {
			setError("Couldn't reach the mail server. Please try again.");
			setState("error");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-black",
				children: "Enquiry emails"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Each enquiry is emailed to the admissions inbox and confirmed back to the applicant. Send yourself a sample to check the settings and see exactly what arrives."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: handleSend,
				disabled: state === "sending",
				className: "mt-6 rounded-full bg-primary px-6 py-2 text-sm font-bold text-primary-foreground disabled:opacity-60",
				children: state === "sending" ? "Sending…" : "Send me a sample enquiry email"
			}),
			state === "sent" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm font-semibold text-primary",
				children: "Sample sent — check your inbox."
			}),
			state === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm font-semibold text-destructive",
				children: error
			})
		]
	});
}
//#endregion
export { AdminPage as component };
