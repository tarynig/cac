import { o as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as separateFeeTotalOf, i as formatZar, n as dualSaving, o as separateMonths } from "./courses-Q7G0sZVb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/course-cards-CAIxUXbi.js
var import_jsx_runtime = require_jsx_runtime();
function FeeLine({ fee, deposit }) {
	if (fee === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm font-semibold text-muted-foreground",
		children: ["Fees on request — ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/contact",
			className: "text-primary underline",
			children: "get the fee sheet"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm font-semibold",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-xl font-black text-primary",
			children: formatZar(fee)
		}), deposit !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "ml-2 text-muted-foreground",
			children: [
				"· ",
				formatZar(deposit),
				" deposit to secure your seat"
			]
		})]
	});
}
function CourseCard({ course }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex h-full flex-col rounded-2xl border border-border bg-card p-6 shadow-sm transition-shadow hover:shadow-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-black",
					children: course.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "shrink-0 rounded-full bg-accent px-3 py-1 text-xs font-bold text-accent-foreground",
					children: [course.months, " months"]
				})]
			}),
			course.signature && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-2 w-fit rounded-full bg-gold px-3 py-1 text-[0.65rem] font-black tracking-widest text-gold-foreground uppercase",
				children: "Signature course"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm font-semibold text-secondary",
				children: course.award
			}),
			course.saqa && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: ["SAQA ID: ", course.saqa]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 flex-1 text-sm leading-relaxed text-muted-foreground",
				children: course.description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 border-t border-border pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeLine, {
					fee: course.fee,
					deposit: course.deposit
				})
			})
		]
	});
}
function DualCard({ dual, courses }) {
	const parts = dual.courseIds.map((id) => courses.find((c) => c.id === id)).filter(Boolean);
	const apart = separateMonths(courses, dual);
	const monthsSaved = Math.max(apart - dual.months, 0);
	const saving = dualSaving(courses, dual);
	const separate = separateFeeTotalOf(courses, dual);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex h-full flex-col rounded-2xl border-2 border-secondary/40 bg-card p-6 shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-black",
					children: dual.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "shrink-0 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground",
					children: [dual.months, " months"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-2",
				children: parts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 size-1.5 shrink-0 rounded-full bg-secondary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: p.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [" · ", p.award]
					})] })]
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-wrap gap-2 text-xs font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-accent px-3 py-1 text-accent-foreground",
					children: monthsSaved > 0 ? `${monthsSaved} months faster than one after the other` : "Two qualifications, one timeline"
				}), saving !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full bg-gold px-3 py-1 text-gold-foreground",
					children: ["Save ", formatZar(saving)]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-auto border-t border-border pt-4",
				children: dual.fee === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeLine, {
					fee: null,
					deposit: null
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-semibold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl font-black text-primary",
							children: formatZar(dual.fee)
						}),
						separate !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 text-muted-foreground line-through",
							children: formatZar(separate)
						}),
						dual.deposit !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-muted-foreground",
							children: [formatZar(dual.deposit), " deposit to secure your seat"]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { DualCard as n, CourseCard as t };
