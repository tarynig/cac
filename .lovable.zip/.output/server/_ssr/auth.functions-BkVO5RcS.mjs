import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { i as stringType, r as objectType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.functions-BkVO5RcS.js
var getCurrentUser_createServerFn_handler = createServerRpc({
	id: "5d9211d3240dce68af5737fec078ee48fb5558618e9bd41f21d3c6986043680d",
	name: "getCurrentUser",
	filename: "src/lib/auth.functions.ts"
}, (opts) => getCurrentUser.__executeServer(opts));
var getCurrentUser = createServerFn({ method: "GET" }).handler(getCurrentUser_createServerFn_handler, async () => {
	const { readSession } = await import("./session.server-CT22DSq1.mjs");
	return await readSession();
});
var signIn_createServerFn_handler = createServerRpc({
	id: "15946b07b54e0909aa27fa0f35669f0600b7c3f449e509501f5aec30c0ba00fd",
	name: "signIn",
	filename: "src/lib/auth.functions.ts"
}, (opts) => signIn.__executeServer(opts));
var signIn = createServerFn({ method: "POST" }).inputValidator((data) => objectType({
	email: stringType().trim().email().max(200),
	password: stringType().min(1).max(200)
}).parse(data)).handler(signIn_createServerFn_handler, async ({ data }) => {
	const { db } = await import("./db.server-BN4FZ3Ea.mjs");
	const { createSession } = await import("./session.server-CT22DSq1.mjs");
	const user = (await db()`
      SELECT id FROM public.app_users
      WHERE lower(email) = lower(${data.email})
        AND is_active
        AND public.verify_password(${data.password}, password_hash)
      LIMIT 1
    `)[0];
	if (!user) return {
		ok: false,
		error: "That email and password don't match."
	};
	await createSession(user.id);
	return { ok: true };
});
var signOut_createServerFn_handler = createServerRpc({
	id: "95f2cf03275bf7421044cb43581f390444f8462eb7ceef40d1fbcdaa0f979964",
	name: "signOut",
	filename: "src/lib/auth.functions.ts"
}, (opts) => signOut.__executeServer(opts));
var signOut = createServerFn({ method: "POST" }).handler(signOut_createServerFn_handler, async () => {
	const { destroySession } = await import("./session.server-CT22DSq1.mjs");
	await destroySession();
	return { ok: true };
});
var changePassword_createServerFn_handler = createServerRpc({
	id: "99a6241c2e872ac588fb9e911f1c19e326e4ed158596fc59ad6d76613657d027",
	name: "changePassword",
	filename: "src/lib/auth.functions.ts"
}, (opts) => changePassword.__executeServer(opts));
var changePassword = createServerFn({ method: "POST" }).inputValidator((data) => objectType({
	currentPassword: stringType().min(1).max(200),
	newPassword: stringType().min(10).max(200)
}).parse(data)).handler(changePassword_createServerFn_handler, async ({ data }) => {
	const { db } = await import("./db.server-BN4FZ3Ea.mjs");
	const { requireUser } = await import("./session.server-CT22DSq1.mjs");
	const user = await requireUser();
	if (!(await db()`
      UPDATE public.app_users
      SET password_hash = public.hash_password(${data.newPassword})
      WHERE id = ${user.id}
        AND public.verify_password(${data.currentPassword}, password_hash)
      RETURNING id
    `)[0]) return {
		ok: false,
		error: "Your current password isn't correct."
	};
	return { ok: true };
});
//#endregion
export { changePassword_createServerFn_handler, getCurrentUser_createServerFn_handler, signIn_createServerFn_handler, signOut_createServerFn_handler };
