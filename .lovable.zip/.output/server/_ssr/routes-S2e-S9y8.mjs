import { n as useSuspenseQuery, o as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as catalogueQueryOptions } from "./catalogue-queries-BI5JU7nB.mjs";
import { n as DualCard } from "./course-cards-CAIxUXbi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-S2e-S9y8.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { data: catalogue } = useSuspenseQuery(catalogueQueryOptions);
	const featuredDuals = catalogue.duals.filter((d) => [
		"d-advanced-graphic",
		"d-film-content",
		"d-music-dj",
		"d-fashion-dd"
	].includes(d.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "surface-deep dot-grid",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-10 px-5 py-20 lg:grid-cols-[1.15fr_0.85fr] lg:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-block rounded-full bg-secondary px-4 py-1.5 text-xs font-black tracking-[0.2em] text-secondary-foreground uppercase",
						children: "2027 Prospectus"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 font-display text-5xl leading-[0.95] font-black text-balance-tight md:text-7xl",
						children: "Where education & industry meet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xl text-base opacity-85",
						children: "Creative Arts College is a division of the South African Film Institute Group. Real industry, relevant education — 30+ accredited SAQA qualifications completed in 12 to 24 months, with hands-on work on industry equipment."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/courses",
							className: "rounded-full bg-secondary px-6 py-3 text-sm font-black text-secondary-foreground transition-opacity hover:opacity-90",
							children: "Explore all courses"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/dual-courses",
							className: "rounded-full border-2 border-primary-foreground/40 px-6 py-3 text-sm font-black transition-colors hover:bg-primary-foreground/10",
							children: "Find a dual course"
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							value: "30+",
							label: "SAQA qualifications"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							value: "12–24",
							label: "Months to qualify"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							value: `${catalogue.duals.length}`,
							label: "Dual pairings"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							value: "99%",
							label: "Pass rate"
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl font-black",
					children: "Seven faculties"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: [catalogue.courses.length, " individual courses across the creative, media, communication and technology sectors."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: catalogue.faculties.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/courses",
						className: "group rounded-2xl border border-border bg-card p-6 transition-colors hover:border-secondary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-lg font-black text-primary",
								children: f.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: f.tagline
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-xs font-black tracking-widest text-secondary uppercase",
								children: [catalogue.courses.filter((c) => c.faculty === f.id).length, " courses →"]
							})
						]
					}, f.id))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-muted py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-black",
						children: "Dual courses"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-2xl text-sm text-muted-foreground",
						children: "Pair two complementary courses, pay a lower combined rate, and finish far sooner than studying them one after the other."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/dual-courses",
						className: "rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground",
						children: [
							"See all ",
							catalogue.duals.length,
							" pairings"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-5 md:grid-cols-2",
					children: featuredDuals.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DualCard, {
						dual: d,
						courses: catalogue.courses
					}, d.id))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border-2 border-secondary bg-card p-8 md:p-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-black",
						children: "You don't need 3–4 years to build a career"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-3xl text-sm leading-relaxed text-muted-foreground md:text-base",
						children: "At Creative Arts College you join the industry from day one. Focused, career-aligned training, development and support puts you on your way to success in 12 to 24 months — with a portfolio, an industry reference and real work experience behind you."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						className: "mt-8 inline-block rounded-full bg-secondary px-6 py-3 text-sm font-black text-secondary-foreground",
						children: "Limited seats — enquire now"
					})
				]
			})
		})
	] });
}
function HeroStat({ value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-primary-foreground/10 p-5 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "font-display text-4xl font-black text-secondary",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 text-xs font-bold tracking-widest uppercase opacity-75",
			children: label
		})]
	});
}
//#endregion
export { Home as component };
