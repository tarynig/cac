import { t as src_default } from "../_libs/postgres.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/db.server-BN4FZ3Ea.js
function connectionString() {
	const url = process.env["DATABASE_URL"];
	if (!url) throw new Error("DATABASE_URL is not configured");
	return url;
}
function db() {
	const url = connectionString();
	const ssl = new URL(url).searchParams.get("sslmode") === "disable" ? false : "require";
	return src_default(url, {
		ssl,
		max: 1,
		idle_timeout: 2,
		connect_timeout: 15,
		prepare: false,
		fetch_types: false
	});
}
//#endregion
export { db };
