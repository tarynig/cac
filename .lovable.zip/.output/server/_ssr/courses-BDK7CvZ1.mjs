import { i as __toESM } from "../_runtime.mjs";
import { n as useSuspenseQuery, o as require_jsx_runtime, s as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as catalogueQueryOptions } from "./catalogue-queries-BI5JU7nB.mjs";
import { t as CourseCard } from "./course-cards-CAIxUXbi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses-BDK7CvZ1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CoursesPage() {
	const { data: catalogue } = useSuspenseQuery(catalogueQueryOptions);
	const [faculty, setFaculty] = (0, import_react.useState)("all");
	const [maxMonths, setMaxMonths] = (0, import_react.useState)(24);
	const filtered = catalogue.courses.filter((c) => (faculty === "all" || c.faculty === faculty) && c.months <= maxMonths);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "surface-deep",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold tracking-[0.3em] text-secondary uppercase",
					children: "2027 Prospectus"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-2xl font-display text-4xl font-black md:text-5xl",
					children: "Every course, one place"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-sm opacity-85 md:text-base",
					children: "Accredited qualifications and CAC skills programmes across seven faculties. Each course is practical, industry-based and completed in 12 to 24 months."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFaculty("all"),
					className: `rounded-full border px-4 py-2 text-sm font-bold transition-colors ${faculty === "all" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:bg-muted"}`,
					children: "All faculties"
				}), catalogue.faculties.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFaculty(f.id),
					className: `rounded-full border px-4 py-2 text-sm font-bold transition-colors ${faculty === f.id ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:bg-muted"}`,
					children: f.name
				}, f.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap items-center gap-4 rounded-2xl border border-border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "duration",
						className: "text-sm font-bold",
						children: "Maximum duration"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "duration",
						type: "range",
						min: 12,
						max: 24,
						step: 3,
						value: maxMonths,
						onChange: (e) => setMaxMonths(Number(e.target.value)),
						className: "h-2 w-56 cursor-pointer accent-[var(--color-secondary)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full bg-accent px-3 py-1 text-sm font-bold text-accent-foreground",
						children: [
							"up to ",
							maxMonths,
							" months"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto text-sm text-muted-foreground",
						children: [
							filtered.length,
							" course",
							filtered.length === 1 ? "" : "s"
						]
					})
				]
			}),
			catalogue.faculties.filter((f) => faculty === "all" || f.id === faculty).map((f) => {
				const list = filtered.filter((c) => c.faculty === f.id);
				if (list.length === 0) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl font-black",
							children: f.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: f.tagline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
							children: list.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourseCard, { course: c }, c.id))
						})
					]
				}, f.id);
			})
		]
	})] });
}
//#endregion
export { CoursesPage as component };
