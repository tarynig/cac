//#region node_modules/.nitro/vite/services/ssr/assets/courses-Q7G0sZVb.js
var dualsForCourse = (catalogue, id) => catalogue.duals.filter((d) => d.courseIds.includes(id));
var formatZar = (value) => new Intl.NumberFormat("en-ZA", {
	style: "currency",
	currency: "ZAR",
	maximumFractionDigits: 0
}).format(value);
/** Individual fees added together, if both are known. */
var separateFeeTotalOf = (courses, dual) => {
	const parts = dual.courseIds.map((id) => courses.find((c) => c.id === id)?.fee ?? null);
	if (parts.some((p) => p === null)) return null;
	return parts.reduce((a, b) => a + b, 0);
};
var dualSaving = (courses, dual) => {
	const total = separateFeeTotalOf(courses, dual);
	if (total === null || dual.fee === null) return null;
	return total - dual.fee;
};
/** Longest individual duration, i.e. what back-to-back study would take. */
var separateMonths = (courses, dual) => dual.courseIds.reduce((sum, id) => sum + (courses.find((c) => c.id === id)?.months ?? 0), 0);
var contact = {
	phone: "081 589 1088",
	website: "www.creativearts.co.za",
	campuses: [{
		city: "Durban",
		phone: "031 301 3313",
		address: "86 Stephen Dlamini Road, Musgrave"
	}, {
		city: "Pietermaritzburg",
		phone: "033 342 2720",
		address: "157 Victoria Road, Victoria Shopping Centre"
	}]
};
//#endregion
export { separateFeeTotalOf as a, formatZar as i, dualSaving as n, separateMonths as o, dualsForCourse as r, contact as t };
