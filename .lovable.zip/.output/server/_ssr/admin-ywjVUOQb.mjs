import { t as CatalogueError } from "./route-fallbacks-DzNM5BHJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-ywjVUOQb.js
var SplitErrorComponent = CatalogueError;
//#endregion
export { SplitErrorComponent as errorComponent };
