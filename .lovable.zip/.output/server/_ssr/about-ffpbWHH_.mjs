import { o as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-ffpbWHH_.js
var import_jsx_runtime = require_jsx_runtime();
var values = [
	{
		title: "Latest qualifications",
		body: "We offer the latest SAQA qualifications that have replaced older legacy qualifications. These include actual work segments and are becoming the industry standard."
	},
	{
		title: "Practical · Immersive",
		body: "All our courses include hands-on engagement. Our classes simulate industry, with learners from related faculties completing actual projects together."
	},
	{
		title: "Industry owned",
		body: "Unlike colleges rooted in education as a business, CAC is owned by an actual industry group — giving learners real access and exposure, not just a piece of paper."
	},
	{
		title: "Dual programmes",
		body: "Gain a competitive advantage by expanding your scope. Select two strategically paired courses to increase your chance of success."
	},
	{
		title: "Contact · Blended",
		body: "Study through an engaging contact medium or a flexible blended medium (SC options). Either way, nothing can stop you from succeeding."
	},
	{
		title: "Industry aligned",
		body: "We partner with the biggest production and tech companies in the country, giving learners direct access on set and behind the scenes."
	}
];
var included = [
	{
		title: "Education",
		items: [
			"Quality-assured education",
			"Knowledge · Skills · Experience",
			"99% pass rate",
			"Certification + graduation"
		]
	},
	{
		title: "Industry",
		items: [
			"Industry access",
			"Production company reference",
			"Work-integrated learning",
			"Internship"
		]
	},
	{
		title: "Portfolio",
		items: [
			"Digital portfolio",
			"Company reference letter",
			"Showreel",
			"Demotape",
			"Photoshoot"
		]
	},
	{
		title: "CV-Booster",
		items: [
			"Leveraging AI as a Creative",
			"Leveraging AI as a Business",
			"Accessing Funding",
			"Branding 101"
		]
	}
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "surface-deep",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold tracking-[0.3em] text-secondary uppercase",
						children: "About"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-3xl font-display text-4xl font-black md:text-5xl",
						children: "Here, you don't just join a college — you join the industry"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl text-sm opacity-85 md:text-base",
						children: "Creative Arts College is an award-winning Institute of Excellence (DHET-ISOE) specialising in accredited, globally recognised and relevant programmes with a practical focus and hands-on experience on industry equipment."
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-black",
				children: "Why learners choose CAC"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
				children: values.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-lg font-black text-primary",
						children: v.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted-foreground",
						children: v.body
					})]
				}, v.title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 pb-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-black",
				children: "What every programme includes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-4",
				children: included.map((block) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-muted p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-sm font-black tracking-widest text-primary uppercase",
						children: block.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-sm text-muted-foreground",
						children: block.items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 size-1.5 shrink-0 rounded-full bg-secondary" }), i]
						}, i))
					})]
				}, block.title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-5 pb-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-black",
						children: "Accreditation"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-3xl text-sm leading-relaxed text-muted-foreground",
						children: "The South African Film Institute (T/A Creative Arts College) is accredited under DHET's Quality Council QCTO (Quality Council for Trades and Occupations), as well as MICT-SETA and CATHSSETA. Collectively we offer approximately 30 specialist SAQA qualifications alongside our own industry-relevant, provider-based skills programmes. CAC is also accredited under the professional body for Information Technology and 4IR, the Institute of Chartered IT Professionals (ICITP)."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs font-bold tracking-widest text-muted-foreground uppercase",
						children: "PR20250064GP"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
						className: "mt-6 border-l-4 border-secondary pl-4 text-sm italic text-muted-foreground",
						children: ["\"South Africa is moving towards a modern, high-quality occupational qualifications system that responds to the needs of industry, strengthens the competitiveness of our economy and expands opportunities for all.\"", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 block not-italic font-bold text-foreground",
							children: "Buti Manamela, Minister of Higher Education and Training"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/courses",
						className: "mt-8 inline-block rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground",
						children: "Browse the 2027 courses"
					})
				]
			})
		})
	] });
}
//#endregion
export { AboutPage as component };
