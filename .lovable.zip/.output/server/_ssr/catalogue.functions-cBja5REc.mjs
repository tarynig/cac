import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { i as stringType, r as objectType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalogue.functions-cBja5REc.js
var toNumber = (value) => value === null || value === void 0 ? null : Number(value);
var getCatalogue_createServerFn_handler = createServerRpc({
	id: "2a5f9abb9b53045eb26c71816c1a497d1c2f2b46176d16f7bde5d4ea8a3904c1",
	name: "getCatalogue",
	filename: "src/lib/catalogue.functions.ts"
}, (opts) => getCatalogue.__executeServer(opts));
var getCatalogue = createServerFn({ method: "GET" }).handler(getCatalogue_createServerFn_handler, async () => {
	const { db } = await import("./db.server-BN4FZ3Ea.mjs");
	const sql = db();
	try {
		const [facultyRows, courseRows, dualRows] = await Promise.all([
			sql`
          SELECT id, name, tagline FROM public.faculties ORDER BY sort_order
        `,
			sql`
          SELECT id, faculty_id, name, months, type, award, saqa, description,
                 fee, deposit, signature
          FROM public.courses
          ORDER BY sort_order
        `,
			sql`
          SELECT d.id, d.title, d.faculty_id, d.months, d.fee, d.deposit,
                 COALESCE(
                   (SELECT array_agg(i.course_id ORDER BY i.position)
                    FROM public.dual_course_courses i
                    WHERE i.dual_id = d.id),
                   '{}'::text[]
                 ) AS course_ids
          FROM public.dual_courses d
          ORDER BY d.sort_order
        `
		]);
		return {
			faculties: facultyRows.map((f) => ({
				id: f.id,
				name: f.name,
				tagline: f.tagline
			})),
			courses: courseRows.map((c) => ({
				id: c.id,
				name: c.name,
				faculty: c.faculty_id,
				months: c.months,
				type: c.type,
				award: c.award,
				...c.saqa ? { saqa: c.saqa } : {},
				description: c.description,
				fee: toNumber(c.fee),
				deposit: toNumber(c.deposit),
				signature: c.signature
			})),
			duals: dualRows.map((d) => ({
				id: d.id,
				title: d.title,
				faculty: d.faculty_id,
				courseIds: [d.course_ids[0] ?? "", d.course_ids[1] ?? ""],
				months: d.months,
				fee: toNumber(d.fee),
				deposit: toNumber(d.deposit)
			}))
		};
	} catch (error) {
		console.error("Catalogue read failed:", error);
		return {
			faculties: [],
			courses: [],
			duals: []
		};
	}
});
var enquirySchema = objectType({
	fullName: stringType().trim().min(2).max(120),
	phone: stringType().trim().min(5).max(40),
	email: stringType().trim().email().max(200),
	courseId: stringType().max(80).nullable().optional(),
	dualCourseId: stringType().max(80).nullable().optional(),
	campus: stringType().trim().min(1).max(80),
	message: stringType().trim().max(2e3).nullable().optional()
});
var submitEnquiry_createServerFn_handler = createServerRpc({
	id: "f7608082995bee451bb3517974e4627a2cd7496f0631b1afb00f5845804a30ed",
	name: "submitEnquiry",
	filename: "src/lib/catalogue.functions.ts"
}, (opts) => submitEnquiry.__executeServer(opts));
var submitEnquiry = createServerFn({ method: "POST" }).inputValidator((data) => enquirySchema.parse(data)).handler(submitEnquiry_createServerFn_handler, async ({ data }) => {
	const { db } = await import("./db.server-BN4FZ3Ea.mjs");
	const { sendMail, teamRecipients } = await import("./mail.server-D2Mx1xYT.mjs");
	const { applicantEnquiryEmail, teamEnquiryEmail } = await import("./enquiry-emails-DHB9DgmV.mjs");
	const sql = db();
	try {
		let interest = "Not sure yet";
		if (data.courseId) interest = (await sql`
          SELECT name FROM public.courses WHERE id = ${data.courseId} LIMIT 1
        `)[0]?.name ?? interest;
		else if (data.dualCourseId) interest = (await sql`
          SELECT title FROM public.dual_courses WHERE id = ${data.dualCourseId} LIMIT 1
        `)[0]?.title ?? interest;
		const enquiry = {
			reference: ((await sql`
        INSERT INTO public.enquiries
          (full_name, phone, email, course_id, dual_course_id, campus, message)
        VALUES (
          ${data.fullName},
          ${data.phone},
          ${data.email},
          ${data.courseId ?? null},
          ${data.dualCourseId ?? null},
          ${data.campus},
          ${data.message ?? null}
        )
        RETURNING id
      `)[0]?.id ?? "").slice(0, 8).toUpperCase(),
			fullName: data.fullName,
			email: data.email,
			phone: data.phone,
			campus: data.campus,
			interest,
			message: data.message ?? null,
			receivedAt: /* @__PURE__ */ new Date()
		};
		const team = teamRecipients();
		if (team.length === 0) console.warn("[mail] ADMISSIONS_EMAIL is not set — no admissions inbox to notify");
		await Promise.all([sendMail({
			to: enquiry.email,
			...applicantEnquiryEmail(enquiry)
		}), ...team.map((address) => sendMail({
			to: address,
			...teamEnquiryEmail(enquiry)
		}))]);
		return { ok: true };
	} catch (error) {
		console.error("Enquiry insert failed:", error);
		return {
			ok: false,
			error: "We couldn't send your enquiry — please try again or call us."
		};
	}
});
//#endregion
export { getCatalogue_createServerFn_handler, submitEnquiry_createServerFn_handler };
