import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { i as stringType, n as numberType, r as objectType, t as enumType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-B7FI_5o0.js
var getAdminSession_createServerFn_handler = createServerRpc({
	id: "e79aab6a9c5d4179f7a176a6a650c1161fe7e7439ce653697dcfba8240b8006e",
	name: "getAdminSession",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getAdminSession.__executeServer(opts));
var getAdminSession = createServerFn({ method: "GET" }).handler(getAdminSession_createServerFn_handler, async () => {
	const { readSession } = await import("./session.server-CT22DSq1.mjs");
	const user = await readSession();
	return {
		isAdmin: user?.role === "admin",
		email: user?.email ?? ""
	};
});
var getAdminEnquiries_createServerFn_handler = createServerRpc({
	id: "cbb9ec5068dc71699afb69ddeb7af1aba85e7ac03f0b71dda8f59fa196a9b26a",
	name: "getAdminEnquiries",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getAdminEnquiries.__executeServer(opts));
var getAdminEnquiries = createServerFn({ method: "GET" }).handler(getAdminEnquiries_createServerFn_handler, async () => {
	const { db } = await import("./db.server-BN4FZ3Ea.mjs");
	const { requireAdmin } = await import("./session.server-CT22DSq1.mjs");
	await requireAdmin();
	return (await db()`
      SELECT id, full_name, phone, email, course_id, dual_course_id, campus,
             message, status, created_at
      FROM public.enquiries
      ORDER BY created_at DESC
    `).map((row) => ({
		id: row.id,
		fullName: row.full_name,
		phone: row.phone,
		email: row.email,
		courseId: row.course_id,
		dualCourseId: row.dual_course_id,
		campus: row.campus,
		message: row.message,
		status: row.status,
		createdAt: new Date(row.created_at).toISOString()
	}));
});
var setEnquiryStatus_createServerFn_handler = createServerRpc({
	id: "1c425e3d55481dab9f73d0579f2f2099b3bfd62368d0a58b68d9036f158f3052",
	name: "setEnquiryStatus",
	filename: "src/lib/admin.functions.ts"
}, (opts) => setEnquiryStatus.__executeServer(opts));
var setEnquiryStatus = createServerFn({ method: "POST" }).inputValidator((data) => objectType({
	id: stringType().uuid(),
	status: enumType([
		"new",
		"contacted",
		"enrolled",
		"closed"
	])
}).parse(data)).handler(setEnquiryStatus_createServerFn_handler, async ({ data }) => {
	const { db } = await import("./db.server-BN4FZ3Ea.mjs");
	const { requireAdmin } = await import("./session.server-CT22DSq1.mjs");
	await requireAdmin();
	await db()`
      UPDATE public.enquiries SET status = ${data.status} WHERE id = ${data.id}
    `;
	return { ok: true };
});
var setFees_createServerFn_handler = createServerRpc({
	id: "a3daecf7ed272fa460dda5277a596af00aa4bf933ae45ddd9b54d1bb1bce087f",
	name: "setFees",
	filename: "src/lib/admin.functions.ts"
}, (opts) => setFees.__executeServer(opts));
var setFees = createServerFn({ method: "POST" }).inputValidator((data) => objectType({
	kind: enumType(["course", "dual"]),
	id: stringType().min(1).max(80),
	fee: numberType().min(0).max(1e7).nullable(),
	deposit: numberType().min(0).max(1e7).nullable()
}).parse(data)).handler(setFees_createServerFn_handler, async ({ data }) => {
	const { db } = await import("./db.server-BN4FZ3Ea.mjs");
	const { requireAdmin } = await import("./session.server-CT22DSq1.mjs");
	await requireAdmin();
	const sql = db();
	if (data.kind === "course") await sql`
        UPDATE public.courses SET fee = ${data.fee}, deposit = ${data.deposit}
        WHERE id = ${data.id}
      `;
	else await sql`
        UPDATE public.dual_courses SET fee = ${data.fee}, deposit = ${data.deposit}
        WHERE id = ${data.id}
      `;
	return { ok: true };
});
var sendTestEmail_createServerFn_handler = createServerRpc({
	id: "cf361682af2d298d02de7c0ec6763b8ac233c3c2cada447d7edee0ac2ab23e41",
	name: "sendTestEmail",
	filename: "src/lib/admin.functions.ts"
}, (opts) => sendTestEmail.__executeServer(opts));
var sendTestEmail = createServerFn({ method: "POST" }).handler(sendTestEmail_createServerFn_handler, async () => {
	const { requireAdmin } = await import("./session.server-CT22DSq1.mjs");
	const user = await requireAdmin();
	const { mailConfigured, sendMail } = await import("./mail.server-D2Mx1xYT.mjs");
	const { teamEnquiryEmail } = await import("./enquiry-emails-DHB9DgmV.mjs");
	if (!mailConfigured()) return {
		ok: false,
		error: "Mail isn't set up on this server yet — the mail account settings are missing."
	};
	const sample = {
		reference: "SAMPLE01",
		fullName: "Jane Learner",
		email: "jane.learner@example.com",
		phone: "082 555 0134",
		campus: "Durban",
		interest: "Dual: Graphic Design + Photography",
		message: "This is a sample message so you can see how a real enquiry will look.",
		receivedAt: /* @__PURE__ */ new Date()
	};
	const result = await sendMail({
		to: user.email,
		...teamEnquiryEmail(sample)
	});
	if (!result.sent) return {
		ok: false,
		error: result.reason === "not_configured" ? "Mail isn't set up on this server yet — the mail account settings are missing." : "The mail server refused the message — please check the mail account settings."
	};
	return { ok: true };
});
//#endregion
export { getAdminEnquiries_createServerFn_handler, getAdminSession_createServerFn_handler, sendTestEmail_createServerFn_handler, setEnquiryStatus_createServerFn_handler, setFees_createServerFn_handler };
