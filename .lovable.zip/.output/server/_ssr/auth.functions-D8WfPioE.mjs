import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C9ESveN_.mjs";
import { i as stringType, r as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.functions-D8WfPioE.js
var getCurrentUser = createServerFn({ method: "GET" }).handler(createSsrRpc("5d9211d3240dce68af5737fec078ee48fb5558618e9bd41f21d3c6986043680d"));
var signIn = createServerFn({ method: "POST" }).inputValidator((data) => objectType({
	email: stringType().trim().email().max(200),
	password: stringType().min(1).max(200)
}).parse(data)).handler(createSsrRpc("15946b07b54e0909aa27fa0f35669f0600b7c3f449e509501f5aec30c0ba00fd"));
var signOut = createServerFn({ method: "POST" }).handler(createSsrRpc("95f2cf03275bf7421044cb43581f390444f8462eb7ceef40d1fbcdaa0f979964"));
var changePassword = createServerFn({ method: "POST" }).inputValidator((data) => objectType({
	currentPassword: stringType().min(1).max(200),
	newPassword: stringType().min(10).max(200)
}).parse(data)).handler(createSsrRpc("99a6241c2e872ac588fb9e911f1c19e326e4ed158596fc59ad6d76613657d027"));
//#endregion
export { signOut as i, getCurrentUser as n, signIn as r, changePassword as t };
