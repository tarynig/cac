import { i as __toESM } from "../_runtime.mjs";
import { n as useSuspenseQuery, o as require_jsx_runtime, s as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { o as separateMonths, r as dualsForCourse } from "./courses-Q7G0sZVb.mjs";
import { t as catalogueQueryOptions } from "./catalogue-queries-BI5JU7nB.mjs";
import { n as DualCard } from "./course-cards-CAIxUXbi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dual-courses-DoXLJVlo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DualPage() {
	const { data: catalogue } = useSuspenseQuery(catalogueQueryOptions);
	const [selected, setSelected] = (0, import_react.useState)("");
	const results = (0, import_react.useMemo)(() => selected ? dualsForCourse(catalogue, selected) : catalogue.duals, [catalogue, selected]);
	const pairableCourses = catalogue.courses.filter((c) => dualsForCourse(catalogue, c.id).length > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "surface-deep dot-grid",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold tracking-[0.3em] text-secondary uppercase",
					children: "Greater value · Competitive advantage"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-3xl font-display text-4xl font-black md:text-5xl",
					children: "Two qualifications. One timeline. One lower fee."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-sm opacity-85 md:text-base",
					children: "Our dual programmes strategically pair complementary courses. Because the two run alongside each other, you finish significantly faster than doing them back to back — and the combined fee is lower than paying for both separately."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-5 py-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-border bg-card p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-black",
					children: "Dual-course finder"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Pick the course you already have in mind and we'll show everything it pairs with."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: selected,
							onChange: (e) => setSelected(e.target.value),
							"aria-label": "Choose a course",
							className: "min-w-64 rounded-xl border border-input bg-background px-4 py-3 text-sm font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Show all dual courses"
							}), catalogue.faculties.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
								label: f.name,
								children: pairableCourses.filter((c) => c.faculty === f.id).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c.id,
									children: c.name
								}, c.id))
							}, f.id))]
						}),
						selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSelected(""),
							className: "rounded-xl border border-border px-4 py-3 text-sm font-bold text-muted-foreground hover:bg-muted",
							children: "Clear"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-auto text-sm font-semibold text-muted-foreground",
							children: [
								results.length,
								" pairing",
								results.length === 1 ? "" : "s"
							]
						})
					]
				}),
				results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-6 grid gap-4 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Shortest pairing",
							value: `${Math.min(...results.map((d) => d.months))} months`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Most time saved",
							value: `${Math.max(...results.map((d) => separateMonths(catalogue.courses, d) - d.months))} months`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Qualifications earned",
							value: "2 per pairing"
						})
					]
				})
			]
		}), results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-10 rounded-2xl border border-border bg-card p-8 text-center text-sm text-muted-foreground",
			children: "This course is currently offered on its own. Speak to us about a custom combination."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-10 grid gap-5 md:grid-cols-2",
			children: results.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DualCard, {
				dual: d,
				courses: catalogue.courses
			}, d.id))
		})]
	})] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-muted p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs font-bold tracking-widest text-muted-foreground uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-display text-xl font-black text-primary",
			children: value
		})]
	});
}
//#endregion
export { DualPage as component };
