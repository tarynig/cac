import { n as CatalogueNotFound } from "./route-fallbacks-DzNM5BHJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-8wpAoqiU.js
var SplitNotFoundComponent = CatalogueNotFound;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
