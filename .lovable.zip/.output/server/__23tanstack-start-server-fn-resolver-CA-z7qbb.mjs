//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-CA-z7qbb.js
var manifest = {
	"15946b07b54e0909aa27fa0f35669f0600b7c3f449e509501f5aec30c0ba00fd": {
		functionName: "signIn_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-BkVO5RcS.mjs")
	},
	"1c425e3d55481dab9f73d0579f2f2099b3bfd62368d0a58b68d9036f158f3052": {
		functionName: "setEnquiryStatus_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-B7FI_5o0.mjs")
	},
	"2a5f9abb9b53045eb26c71816c1a497d1c2f2b46176d16f7bde5d4ea8a3904c1": {
		functionName: "getCatalogue_createServerFn_handler",
		importer: () => import("./_ssr/catalogue.functions-cBja5REc.mjs")
	},
	"5d9211d3240dce68af5737fec078ee48fb5558618e9bd41f21d3c6986043680d": {
		functionName: "getCurrentUser_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-BkVO5RcS.mjs")
	},
	"95f2cf03275bf7421044cb43581f390444f8462eb7ceef40d1fbcdaa0f979964": {
		functionName: "signOut_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-BkVO5RcS.mjs")
	},
	"99a6241c2e872ac588fb9e911f1c19e326e4ed158596fc59ad6d76613657d027": {
		functionName: "changePassword_createServerFn_handler",
		importer: () => import("./_ssr/auth.functions-BkVO5RcS.mjs")
	},
	"a3daecf7ed272fa460dda5277a596af00aa4bf933ae45ddd9b54d1bb1bce087f": {
		functionName: "setFees_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-B7FI_5o0.mjs")
	},
	"cbb9ec5068dc71699afb69ddeb7af1aba85e7ac03f0b71dda8f59fa196a9b26a": {
		functionName: "getAdminEnquiries_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-B7FI_5o0.mjs")
	},
	"cf361682af2d298d02de7c0ec6763b8ac233c3c2cada447d7edee0ac2ab23e41": {
		functionName: "sendTestEmail_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-B7FI_5o0.mjs")
	},
	"e79aab6a9c5d4179f7a176a6a650c1161fe7e7439ce653697dcfba8240b8006e": {
		functionName: "getAdminSession_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-B7FI_5o0.mjs")
	},
	"f7608082995bee451bb3517974e4627a2cd7496f0631b1afb00f5845804a30ed": {
		functionName: "submitEnquiry_createServerFn_handler",
		importer: () => import("./_ssr/catalogue.functions-cBja5REc.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
